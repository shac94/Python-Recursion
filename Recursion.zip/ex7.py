# shaharc1994
# 205801541
# shahar cohen

OPEN_PARENTHESES = '('
CLOSE_PARENTHESES = ')'
START_OPEN_PARENTHESES = 1
START_CLOSE_PARENTHESES = 0
EMPTY_STRING = ''
EMPTY_LST = []


def print_to_n(n):
    """
    this function print numbers from 1 to n in ascending order
    :param n:number
    :return:none
    """
    if n < 1:
        return
    if n == 1:
        print(n)
        return
    print_to_n(n - 1)
    print(n)


def digit_sum(n):
    """
    this function sum the digits of positive number n
    :param n:number
    :return:sum the digits of n
    """
    if n < 0:
        return
    if n < 1:
        return 0
    if n < 10:
        return n
    return int(digit_sum(n / 10)) + n % 10


def is_prime(n):
    """
    this function check if the number n is prime bt returning True / False
    :param n: number
    :return: True / False
    """
    return dont_have_divisor_smaller_than(n, int(n ** 0.5))


def dont_have_divisor_smaller_than(n, n_root):
    """
    this function check if the number n have a divisor smaller then is root
    :param n: number
    :param n_root: number root (change)
    :return: True / False
    """
    if n < 1:
        return False
    if n == 1:
        return False
    if n_root == 1:
        return True
    if n % n_root == 0:
        return False
    return dont_have_divisor_smaller_than(n, n_root - 1)


def play_hanoi(hanoi, n, src, dst, temp):
    """
    this function solve the game "hanoi tower"
    it move a ring to a tower by the  game rules
    :param hanoi: graph object for the game
    :param n: number of rings
    :param src: the tower with the rings
    :param dst: the tower we need to move the rings to
    :param temp: temporary tower use as layout for the rings to organize
    and win the game
    :return:
    """
    if n <= 0:
        return
    if n == 1:
        hanoi.move(src, dst)
        return
    play_hanoi(hanoi, n - 1, src, temp, dst)
    hanoi.move(src, dst)
    play_hanoi(hanoi, n - 1, temp, dst, src)


def print_sequences(char_list, n):
    """
    this function get a list of letters and a number and print all the
    possible combination of n length of charters from the list
    important- same character can appear more then once
    :param char_list:list of letters
    :param n:length string
    :return:""
    """
    recursion_sequences(char_list, n, "")


def recursion_sequences(char_list, n, string):
    """
    this function get a list of letters and a number and empty string and
    print all the possible combination of n length of charters from the list
    important- same character can appear more then once its the core of
    function print_sequences
    :param char_list:
    :param n:
    :param string:
    :return: ""
    """
    if len(string) == n:
        print(string)
        return
    for letter in char_list:
        recursion_sequences(char_list, n, string + letter)


def print_no_repetition_sequences(char_list, n):
    """
    this function get a list of letters and a number and print all the
    possible combination of n length of charters from the list
    important- same character cant appear more then once
    :param char_list:
    :param n:
    :return:
    """
    recursion_no_repetition_sequences(char_list, n, "")


def recursion_no_repetition_sequences(char_list, n, string):
    """
    this function is the core of the function print_no_repetition_sequences
    its get a list of letters and a number and empty string and print all the
    possible combination of n length of charters from the list
    important- same character cant appear more then once
    :param char_list:
    :param n:
    :param string:
    :return:
    """
    if n == len(string):
        print(string)
        return
    for letter in char_list:
        if letter in string:
            continue
        recursion_no_repetition_sequences(char_list, n, string + letter)


def parentheses(n):
    """
    this function get a number n and return  list of all the possible
    combination of parentheses while it must be close by a close parentheses )
    :param n:number
    :return:list of strings
    """
    if n < 0:
        return
    if n == 0:
        return [EMPTY_STRING]
    lst = EMPTY_LST[:]
    recursion_parentheses(n, OPEN_PARENTHESES, lst,
                          START_OPEN_PARENTHESES,
                          START_CLOSE_PARENTHESES)
    return lst


def recursion_parentheses(n, string, parentheses_list,
                          number_of_open_parentheses,
                          number_of_close_parentheses):
    """
    this function is helper for the function parentheses she get number n
    empty string empty list and number of open and close parentheses and
    change the list
    :param n: ""
    :param string: ""
    :param parentheses_list: ""
    :param number_of_open_parentheses: )
    :param number_of_close_parentheses: (
    :return: ""
    """
    if len(string) == 2 * n:
        parentheses_list.append(string)
        return
    if number_of_open_parentheses < n:
        recursion_parentheses(n, string + OPEN_PARENTHESES,
                              parentheses_list, number_of_open_parentheses + 1,
                              number_of_close_parentheses)
    if number_of_close_parentheses < n and \
            number_of_close_parentheses < number_of_open_parentheses:
        recursion_parentheses(n, string + CLOSE_PARENTHESES,
                              parentheses_list, number_of_open_parentheses,
                              number_of_close_parentheses + 1)
    return


def flood_fill(image, start):
    """
    this function get a two dimensional array and a start position in this
    array she transform '.' to '*' by the game rules and change the array by
    the start input and the array order
    :param image:array
    :param start:start spot
    :return:none
    """
    line = start[0]
    column = start[1]
    if image[line][column] == '*':
        return image
    image[line][column] = '*'
    flood_fill(image, (line - 1, column))
    flood_fill(image, (line + 1, column))
    flood_fill(image, (line, column - 1))
    flood_fill(image, (line, column + 1))
